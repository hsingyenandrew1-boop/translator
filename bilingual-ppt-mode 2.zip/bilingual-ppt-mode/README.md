# Bilingual PPT Mode

PowerPoint task-pane add-in: select a text box, translate it in place with
Google Cloud Translation, formatting untouched.

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Trust the local dev HTTPS certificate (Office requires HTTPS, even on localhost):
   ```
   npm run install-certs
   ```

3. Get a Google Cloud Translation API key (Google Cloud Console → enable
   "Cloud Translation API" → Credentials → create an API key), then:
   ```
   cp .env.example .env
   # edit .env and paste your key into GOOGLE_TRANSLATE_API_KEY
   ```

4. Start the server (serves the add-in files and the /translate proxy):
   ```
   npm start
   ```

5. Sideload the add-in into PowerPoint:
   - **Fastest**: `npx office-addin-debugging start manifest.xml` (auto-sideloads
     and launches PowerPoint with the add-in attached).
   - **Manual**: PowerPoint → Insert → My Add-ins → Upload My Add-in → select
     `manifest.xml`.

## Using it

- **Translate Panel** (ribbon button, Home tab → Bilingual Mode): opens the
  task pane. Pick source/target language, select a text box on the slide,
  click "Translate Selected Shape".
- **Quick Translate** (ribbon button): translates the selected text box
  immediately, using whatever language pair was last set in the task pane
  (defaults to English → Chinese Traditional if never opened).

Both entry points write back the shape's `.text` and, when translating into
Chinese, its font (see Dual-language storage below) — size, color, and
positioning are always untouched.

Translating a shape you've already translated in the other direction is
instant: the exact text and font are restored from a per-shape cache
instead of calling the translator again.

## How it fits together

```
manifest.xml            — ribbon buttons + task pane registration
src/taskpane/           — visible UI: language pickers, translate button
src/commands/           — headless ribbon action (Quick Translate)
src/shared/
  translate-client.js    — translateSelectedShape(): the shared translate
                            flow used by both the task pane and commands.js
  translation-store.js   — per-shape dual-language cache (see below)
  font-map.js             — CJK font fallback for translating into Chinese
server/index.js         — local HTTPS server; serves static files and
                           proxies POST /translate to Google Cloud
                           Translation (keeps the API key server-side)
```

Language direction and the last error from Quick Translate are stored in
`Office.context.document.settings` — shared per-presentation state visible
to both the task pane and the headless command function.

## Dual-language storage

Each shape's English and Chinese versions are cached by `shape.id` in
`Office.context.document.settings` (`translation-store.js`), storing the
exact text *and* font used for each language:

```
{ "shapeTranslations": { "<shape.id>": {
    "en":    { "text": "Hello",  "font": "Arial" },
    "zh-TW": { "text": "你好",    "font": "Microsoft JhengHei" }
} } }
```

The first time a shape is translated, its current text/font is saved
under its own language before being overwritten. From then on, switching
direction is a cache read — text and font are restored exactly, with no
API call. Translating into a language that isn't cached yet still calls
the API and picks a font via `font-map.js`.

## Known gaps / next steps

- Icons in `assets/` are placeholders generated for this scaffold — swap
  in real branding before shipping.
- `<SupportUrl>` in manifest.xml is a placeholder.
- No retry/backoff on Google API failures; a 502 from `/translate` just
  surfaces the raw error message.
- Only the first selected shape is translated; multi-shape selections
  are ignored beyond `items[0]`.
- Font mapping only covers translating *into* Chinese (`font-map.js`);
  translating into a third, uncached language keeps whatever font is
  currently on the shape rather than picking an appropriate one.
- No live "ghost overlay" preview of the other language while editing —
  Office.js has no floating/overlay UI surface for that; it would need a
  VSTO (Windows-only) rewrite, which was deliberately ruled out in favor
  of staying cross-platform.
